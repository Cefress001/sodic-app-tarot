// This file is no longer used as the application has been converted
// to a multi-page HTML/CSS/JavaScript architecture.
// The entry point is now index.html.