// This React component is no longer used.
// The Kavanah input is now a standard HTML textarea element
// within draw.html, styled by css/style.css.
// Its value is handled by js/main.js.