// This React component is no longer used.
// Text display is handled by standard HTML elements (p, span, div)
// and styled with css/style.css. Specific text styling (e.g. first letter)
// would be applied via CSS classes.