// This React component is no longer used.
// Header functionality is now part of the HTML structure in 
// index.html, draw.html, interpretation.html and styled with css/style.css.